#!/bin/bash

for i in {1..12}
do
wget https://s3.amazonaws.com/tripdata/20150$i-citibike-tripdata.zip|xargs unzip -c|tail -n +2 > 2015_0$i.csv
done

for i in {10..12}
do
wget https://s3.amazonaws.com/tripdata/2015$i-citibike-tripdata.zip|xargs unzip -c|tail -n +2 > 2015_$i.csv
done