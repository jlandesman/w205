rm(list=ls())

library(dplyr)
library(lubridate)
library(ggplot2)

data<-read.csv("C:/Users/jlandesman/Downloads/201509-citibike-tripdata/201509-citibike-tripdata.csv", stringsAsFactors=FALSE)
data<-data[complete.cases(data),]
data<-tbl_df(data)

sum(data$tripduration>4000)
sum(data$tripduration>4000)/length(data$tripduration)

data<-filter(data,tripduration<4000) #removing 0.5% of the trips greater than 66 minutes
hist(data$tripduration)

data$age<-2016-data$birth.year #create age variable
data<-filter(data,age<80) #set cutoff equal to 85
data<-data %>%mutate(age.buckets = as.integer(5 * round(data$age/5))) #create age buckets

#Now lets break up each ride into its station pair, day, and hour
sorted.data<-data %>% 
  filter(start.station.id != end.station.id) %>% #remove roundtrips to same station
  mutate(start.time = mdy_hms(starttime)) %>% #fix start_time for narrowing down intervals
  mutate(day = mdy(paste0(month(start.time),"/",day(start.time),"/",year(start.time))),hour = hour(start.time)) %>% #simplify to days and hours
  mutate(gender = ifelse(gender==1,"male","female")) %>% # 0 = male, 1 = female
  mutate(distance = paste0(start.station.id,",", end.station.id)) %>% #create tuples of each station to station pair
  select(distance, day,hour, age, age.buckets,gender,tripduration) #remove unneccessary variables

#New plan - assume that the weather adn traffic etc are constant throughout the month. And use age buckets
monthly.data <- sorted.data %>% 
  group_by(distance,gender,age.buckets) %>% 
  summarize(avg.trip = mean(tripduration)) %>%
  arrange(distance,age.buckets)

#Calculate differentials
monthly.data <- monthly.data %>%
  group_by(distance,gender) %>%
  arrange(distance,age.buckets) %>%
  mutate(delta = c(0,diff(avg.trip)))

##Calculate Percent Differentials 
monthly.data<-monthly.data %>%
  group_by(distance,gender) %>%
  mutate(lowest = ifelse(avg.trip == min(avg.trip),avg.trip,NA)) %>% #generate lowest value
  mutate(lowest = ifelse(is.na(lowest), mean(lowest,na.rm=TRUE),lowest)) %>% # assign lowest value to all entries
  mutate(pct_change = (delta/ lag(avg.trip,1)*100)) # calculate pct change

##Build Distributions
distributions<-monthly.data %>% 
  filter(pct_change<200) %>%
  select(age.buckets,pct_change)

##Plot Distributions! #Incredibly wide range in our data
ggplot(distributions, aes(x = pct_change, fill = factor(age.buckets))) + 
  geom_density(alpha = 0.5) + 
  ggtitle("Distribution of slow down by Age Bucket")

#Lets look by gender
ggplot(distributions, aes(x = pct_change, color = factor(gender))) + 
  geom_density(size=1) +
  ggtitle("Distribution of slow down by Gender")+
  geom_hline(yintercept=0,color="white",size=1)

#Group_by age for mean/ median results!
results<-monthly.data %>%
  filter(age.buckets<80 & age.buckets>20) %>%
  group_by(age.buckets,gender) %>%
  summarize(mean_pct_change = mean(pct_change, na.rm = TRUE),
            median_change = median(pct_change,na.rm=TRUE),
            count = n(),
            sd = sd(pct_change,na.rm=TRUE))

results.plot<-ggplot(results)

##Average
results.plot + 
  geom_bar(aes(x=age.buckets,y=mean_pct_change,fill=factor(gender)),stat="identity",position="dodge") + 
  labs(title = "Average Percent Slowdown by Age Bucket", x="age buckets", y="average percent change in trip duration") + 
  theme(plot.title = element_text("Average percent Slowdown by Age Bucket"))

##Median
results.plot + 
  geom_bar(aes(x=age.buckets,y=median_change,fill=factor(gender)),stat="identity",position="dodge") + 
  labs(title = "Median Percent Slowdown by Age Bucket", x="age buckets", y="median percent change in trip duration") + 
  theme(plot.title = element_text("Median Percent Slowdown by Age Bucket"))

##Median
results.plot + geom_line(aes(x=age.buckets,y=mean_pct_change,color=factor(gender)),stat="identity")

